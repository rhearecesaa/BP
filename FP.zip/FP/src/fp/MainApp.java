package fp;

import java.util.Scanner;

public class MainApp {
    static Scanner sc = new Scanner(System.in);
    public static void main(String[] args) {
        //data barang
        cBarang[] brg = new cBarang[5];
        brg[0] = new cBarang("Burger", 10000);
        brg[1] = new cBarang("Kebab", 15000);
        brg[2] = new cBarang("Spagheti", 20000);
        brg[3]= new cBarang("Pizza", 50000);
        brg[4] = new cBarang("Lumpia Beef", 25000);
        
        cDaftarTransaksi tr = new cDaftarTransaksi();
        int pilih, pilih2, pilih3;
        
        //kode
        int kode=100,jumlah;
        System.out.println("\nSelamat Datang di ");
        System.out.println("APLIKASI PENJUALAN JANJI JIWA & JIWA TOAST - RUKO RUNGKUT");
        System.out.println("By: VIMIRAMA TEAM");
        System.out.println("    - 22082010145 (Mafda Khoirotul Fatha)");
        System.out.println("    - 22082010146 (Rahayu Kartika Sari)");
        System.out.println("    - 22082010147 (Mifa Amira Dewi");
        System.out.println("    - 22082010152 (Viviana Purba)");
        //main menu
        do{
            System.out.println("MENU");
            System.out.println("1. Pembeli");
            System.out.println("2. Member");
            System.out.println("3. Admin");
            System.out.println("4. Pemilik");
            System.out.println("5. Exit");
            System.out.print("Pilih : ");
            pilih = sc.nextInt();
            switch(pilih){
                case 1:
                    kode++;
                    cDaftarTransaksi beli = new cDaftarTransaksi();
                    System.out.print("Nama Pembeli : ");
                    String nama = sc.next();
                    do{
                        System.out.println("\nMasuk Sebagai Pembeli"); 
                        System.out.println("1.Tambah");
                        System.out.println("2.Hapus");
                        System.out.println("3.Lihat");
                        System.out.println("4.Kembali");
                        System.out.print("Pilih = ");
                        pilih2 = sc.nextInt();
                        switch(pilih2){
                            case 1:
                                cTransaksi br = null;
                                System.out.println("Daftar Menu: ");
                                for(int i=0; i<brg.length;i++){
                                    System.out.println((i+1)+". "+brg[i].nama+"\t\t ["+brg[i].harga+"]");
                                }
                                System.out.print("Pilih = ");
                                pilih3 = sc.nextInt();
                                System.out.print("Jumlah = ");
                                jumlah = sc.nextInt();
                                br = new cTransaksi(String.valueOf(kode),brg[pilih3-1],nama,jumlah,0);
                                beli.tambahTransaksi(br);
                                break;
                            case 2:
                                beli.lihatTransaksi(1);
                                System.out.print("Hapus Nomor = ");
                                pilih3=sc.nextInt();
                                System.out.println("Yakin untuk menghapus? (1/0)");
                                System.out.print("Jawab = ");
                                int hapus = sc.nextInt();
                                if(hapus==1){
                                    beli.hapusTransaksi(pilih3);
                                }
                                else{
                                    System.out.println("Hapus Transaksi dibatalkan");
                                }
                                break;
                            case 3:
                                beli.lihatTransaksi(1);
                                break;
                            case 4:
                                tr.sambungTransaksi(beli.getFront(), beli.getRear());
                                System.out.println("Selamat datang kembali..");
                                break;
                        }
                    }while(pilih2!=4);
                    break;
                case 2:
                    //data member
                    cMember[] member = new cMember[4];
                    member[0]= new cMember("Mafda145", "145", "Mafda");
                    member[1]= new cMember("Rahayu146", "146", "Rahayu");
                    member[2]= new cMember("Mifa147", "147", "Mifa");
                    member[3]= new cMember("Vivi152", "152", "Vivi");
                    System.out.println("  Masukkan ID dan Password");
                    System.out.println("ID  = ");
                    String id=sc.next();
                    System.out.println("Pin = ");
                    String pn=sc.next();
                    boolean valid=false; int indeks=0;
                    for(int i=0; i<member.length;i++){
                        if(member[i].idMember.equals(id)){
                            if(member[i].PIN.equals(pn)){
                                valid=true;
                                indeks=i;
                            }
                            else{
                                System.out.println("Maaf PIN anda salah...");
                            }
                        }
                    }
                    if(!valid){
                        System.out.println("Maaf ID Member tidak ditemukan ....");
                    }
                    else{
                        do{
                            cDaftarTransaksi beli2 = new cDaftarTransaksi();
                            String nmem = member[indeks].nama;
                            System.out.println("Selamat Datang .... "+nmem);
                            System.out.println("\nMasuk Sebagai Member"); 
                            System.out.println("1.Tambah");
                            System.out.println("2.Hapus");
                            System.out.println("3.Lihat");
                            System.out.println("4.Kembali");
                            System.out.print("Pilih = ");
                            pilih2=sc.nextInt();
                            switch(pilih2){
                                case 1:
                                    cTransaksi bm = null;
                                    System.out.println("Daftar Menu: ");
                                    for(int i=0; i<brg.length;i++){
                                        System.out.println((i+1)+". "+brg[i].nama+"\t\t ["+brg[i].harga+"]");
                                    }
                                    System.out.print("Pilih = ");
                                    pilih3 = sc.nextInt();
                                    System.out.print("Jumlah = ");
                                    jumlah = sc.nextInt();
                                    bm = new cTransaksi(String.valueOf(kode),brg[pilih3-1],nmem,jumlah,0);
                                    beli2.tambahTransaksi(bm);
                                    break;
                                case 2:
                                    beli2.lihatTransaksi(1);
                                    System.out.print("Hapus Nomor = ");
                                    pilih3=sc.nextInt();
                                    System.out.println("Yakin untuk menghapus? (1/0)");
                                    System.out.print("Jawab = ");
                                    int hapus = sc.nextInt();
                                    if(hapus==1){
                                        beli2.hapusTransaksi(pilih3);
                                    }
                                    else{
                                        System.out.println("Hapus Transaksi dibatalkan");
                                    }
                                case 3:
                                    beli2.lihatTransaksi(2);
                                    break;
                                case 4:
                                    tr.sambungTransaksi(beli2.getFront(), beli2.getRear());
                                    System.out.println("Selamat datang kembali..");
                                    break;
                                }
                            }while(pilih2!=4);
                            break;
                        }
                    break;
                case 3:
                    //data member
                    cAdmin[] admin = new cAdmin[4];
                    admin[0]= new cAdmin("Mafda145", "145", "Mafda");
                    admin[1]= new cAdmin("Rahayu146", "146", "Rahayu");
                    admin[2]= new cAdmin("Mifa147", "147", "Mifa");
                    admin[3]= new cAdmin("Vivi152", "152", "Vivi");
                    System.out.println("  Masukkan ID dan Password");
                    System.out.println("ID  = ");
                    String ida=sc.next();
                    System.out.println("Pin = ");
                    String pna=sc.next();
                    boolean valid2=false; int indeks2=0;
                    for(int i=0; i<admin.length;i++){
                        if(admin[i].idAdmin.equals(ida)){
                            if(admin[i].PIN.equals(pna)){
                                valid=true;
                                indeks=i;
                            }
                            else{
                                System.out.println("Maaf PIN anda salah...");
                            }
                        }
                    }
                    if(!valid2){
                        System.out.println("Maaf ID Admin tidak ditemukan ....");
                    }
                    else{
                        System.out.println("Masuk sebagai Admin");
                        tr.lihatTransaksi(3);
                        cTransaksi t=tr.getFront();
                        do{
                           if(t.getStatus()==0){
                               System.out.println("Kode     : "+t.getKode());
                               System.out.println("Pembeli  : "+t.getPembeli());
                               System.out.println("Barang   : "+t.getBarang().getNama());
                               System.out.println("Jumlah   : "+t.getJumlah());
                               System.out.println("Pilih Aksi");
                               System.out.println("1.Diproses");
                               System.out.println("2.Selesai");
                               System.out.print("Pilih = ");
                               int aksi =sc.nextInt();
                               if(aksi==1){
                                   tr.prosesTransaksi(t);
                                   System.out.println("Berhasil diproses...");
                               }
                               else{
                                   break;
                               }
                           }
                           t=t.next;
                        }while(t!=null);
                        break;
                    }
                    break;
                case 4:
                    System.out.println("Masuk sebagai Pemilik");
                    System.out.println("Transaksi Diproses : "+tr.lihatDiproses());
                    System.out.println("Pemasukan : "+tr.lihatPemasukan());
                case 5:
                    System.out.println("Terima kasih...");
                    break;
            }
        }while(pilih!=5);
    }
}
