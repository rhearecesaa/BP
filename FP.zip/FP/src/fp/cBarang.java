package fp;
public class cBarang {
    String nama;
    int harga;
    
    cBarang(String n, int h){
        nama=n; harga=h;
    }
    
    String getNama(){
        return nama;
    }
    int getHarga(){
        return harga;
    }
}
