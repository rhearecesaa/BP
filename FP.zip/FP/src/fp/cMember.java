package fp;
public class cMember {
    String idMember, PIN, nama;
    cMember(String id, String p, String n){
        idMember=id; PIN=p; nama=n;
    }
}
