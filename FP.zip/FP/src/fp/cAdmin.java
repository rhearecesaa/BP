package fp;
public class cAdmin {
    String idAdmin, PIN, nama;
    cAdmin(String id, String p, String n){
        idAdmin=id; PIN=p; nama=n;
    }
}
